import React from 'react';
import './TodoItem.css';

function TodoItem({ task, index, toggleComplete, deleteTask }) {
  return (
    <div className={`todo-item ${task.completed ? 'completed' : ''}`}>
      <span onClick={() => toggleComplete(index)}>{task.text}</span>
      <button onClick={() => deleteTask(index)}>❌</button>
    </div>
  );
}

export default TodoItem;
